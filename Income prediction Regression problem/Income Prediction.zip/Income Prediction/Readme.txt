The code is in .ipynb(Juypter) file. Need to install category_encoders package in your Anaconda Environmet. It is used to perform Binary Encoding.
Just Type: conda install -c conda-forge category_encoders 
on your Anaconda CMD environment.
Afterward, Code would be up and Running!